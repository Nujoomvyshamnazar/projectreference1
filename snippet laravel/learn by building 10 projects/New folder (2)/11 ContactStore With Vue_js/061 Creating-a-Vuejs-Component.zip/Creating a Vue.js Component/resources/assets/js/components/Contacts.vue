<template>
  <h1>Contacts</h1>
</template>

<script>
  export default {
    data: function(){
      return {}
    },
    mounted: function(){
      console.log('Contacts Component Loaded...');
    }
  }
</script>
